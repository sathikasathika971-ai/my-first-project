const modal = document.getElementById("authModal");
const authForm = document.getElementById("authForm");
const message = document.getElementById("message");
const usernameField = document.querySelector(".register-only");
const formTitle = document.getElementById("formTitle");
const formSubtitle = document.getElementById("formSubtitle");
const submitBtn = document.getElementById("submitBtn");
const dashboard = document.getElementById("dashboard");
const mainContent = document.querySelector("main");
const footer = document.querySelector("footer");

let mode = "login";

function openModal(selectedMode = "login") {
    modal.classList.remove("hidden");
    setMode(selectedMode);
}

function closeModal() {
    modal.classList.add("hidden");
    authForm.reset();
    message.textContent = "";
}

function setMode(newMode) {
    mode = newMode;

    document.querySelectorAll(".tab").forEach(tab => {
        tab.classList.toggle("active", tab.dataset.mode === mode);
    });

    if (mode === "register") {
        usernameField.classList.remove("hidden");
        document.getElementById("username").required = true;
        formTitle.textContent = "Create Account";
        formSubtitle.textContent = "Register to start using StudyMate.";
        submitBtn.textContent = "Register";
    } else {
        usernameField.classList.add("hidden");
        document.getElementById("username").required = false;
        formTitle.textContent = "Welcome Back";
        formSubtitle.textContent = "Login to continue to StudyMate.";
        submitBtn.textContent = "Login";
    }

    message.textContent = "";
}

document.getElementById("loginNav").onclick = () => openModal("login");
document.getElementById("registerNav").onclick = () => openModal("register");
document.getElementById("startBtn").onclick = () => openModal("register");
document.getElementById("closeModal").onclick = closeModal;

document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => setMode(tab.dataset.mode);
});

window.onclick = (event) => {
    if (event.target === modal) closeModal();
};

authForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = {
        username: document.getElementById("username").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    };

    const endpoint = mode === "register" ? "/api/register" : "/api/login";

    try {
        submitBtn.disabled = true;
        submitBtn.textContent = "Please wait...";

        const response = await fetch(endpoint, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            message.textContent = data.message || "Something went wrong.";
            return;
        }

        message.textContent = data.message;

        if (mode === "register") {
            setMode("login");
            document.getElementById("email").value = payload.email;
            document.getElementById("password").value = "";
        } else {
            showDashboard(data.user.username);
            closeModal();
        }
    } catch (error) {
        message.textContent = "Cannot connect to the backend. Make sure Flask is running.";
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = mode === "register" ? "Register" : "Login";
    }
});

function showDashboard(username) {
    mainContent.classList.add("hidden");
    footer.classList.add("hidden");
    dashboard.classList.remove("hidden");
    document.getElementById("dashboardName").textContent = username;
    window.scrollTo(0, 0);
}

document.getElementById("logoutBtn").onclick = async () => {
    await fetch("/api/logout", { method: "POST" });
    dashboard.classList.add("hidden");
    mainContent.classList.remove("hidden");
    footer.classList.remove("hidden");
    window.scrollTo(0, 0);
};

async function checkSession() {
    try {
        const response = await fetch("/api/me");
        const data = await response.json();

        if (data.logged_in) {
            showDashboard(data.username);
        }
    } catch (error) {
        console.log("Backend is not available yet.");
    }
}

checkSession();
