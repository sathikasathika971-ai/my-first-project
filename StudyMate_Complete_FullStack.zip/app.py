from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
CORS(app)

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "YOUR_MYSQL_PASSWORD",
    "database": "studymate"
}

def get_connection():
    return mysql.connector.connect(**DB_CONFIG)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    email = data.get("email", "").strip()
    password = data.get("password", "")

    if not username or not email or not password:
        return jsonify(success=False, message="All fields are required."), 400

    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE email=%s OR username=%s", (email, username))
        if cursor.fetchone():
            return jsonify(success=False, message="Username or email already exists."), 409

        password_hash = generate_password_hash(password)
        cursor.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
            (username, email, password_hash)
        )
        conn.commit()
        return jsonify(success=True, message="Registration successful.")
    except Error as e:
        return jsonify(success=False, message=f"Database error: {e}"), 500
    finally:
        try:
            cursor.close()
            conn.close()
        except:
            pass

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip()
    password = data.get("password", "")

    if not email or not password:
        return jsonify(success=False, message="Email and password are required."), 400

    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, username, email, password_hash FROM users WHERE email=%s",
            (email,)
        )
        user = cursor.fetchone()

        if not user or not check_password_hash(user["password_hash"], password):
            return jsonify(success=False, message="Invalid email or password."), 401

        session["user_id"] = user["id"]
        session["username"] = user["username"]

        return jsonify(
            success=True,
            message="Login successful.",
            user={"id": user["id"], "username": user["username"], "email": user["email"]}
        )
    except Error as e:
        return jsonify(success=False, message=f"Database error: {e}"), 500
    finally:
        try:
            cursor.close()
            conn.close()
        except:
            pass

@app.route("/api/me", methods=["GET"])
def me():
    if "user_id" not in session:
        return jsonify(logged_in=False)
    return jsonify(logged_in=True, username=session["username"])

@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify(success=True, message="Logged out.")

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
